import { createAsyncThunk, createSlice, createAction } from "@reduxjs/toolkit";

const initialState = {
  loggedInUser: null,
  loading: false,
  error: null,
};

export const registerNewUser = createAsyncThunk(
  "registerNewUser",
  async ({ data, navigate }, thunkAPI) => {
    console.log("The data for body of request is: ", data);
    const res = await fetch("http://127.0.0.1:8000/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
      credentials: "include",
    });

    const response = await res.json();

    if (res.ok) {
      console.log("The response is ok");
      navigate("/");
    } else {
      return thunkAPI.rejectWithValue(response);
    }

    console.log(response);

    return response;
  }
);

export const loginUser = createAsyncThunk(
  "loginUser",
  async ({ data, navigate }, thunkAPI) => {
    console.log("The data for body of request is: ", data);
    const res = await fetch("http://127.0.0.1:8000/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
      credentials: "include",
    });

    const response = await res.json();

    if (res.ok) {
      console.log("The response is ok");
      navigate("/");
    } else {
      return thunkAPI.rejectWithValue(response);
    }

    console.log(response);

    return response;
  }
);

const refreshToken = async () => {
  try {
    const res = await fetch("http://127.0.0.1:8000/refresh-token", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      credentials: "include", // Include cookies in the request
    });

    if (!res.ok) {
      throw new Error("Failed to refresh token");
    }

    const response = await res.json();
    console.log("Token refreshed successfully:", response);

    return response;
  } catch (error) {
    console.error("Error refreshing token:", error);
    throw error;
  }
};

export const getUserDetails = createAsyncThunk("getUserDetails", async () => {
  const res = await fetch("http://127.0.0.1:8000/user", {
    credentials: "include",
  });

  const response = await res.json();

  console.log("The response for get user details:", response);

  if (response.detail == "Authentication credentials were not provided.") {
    console.log("The response after refereshing token is: ", refreshToken());
  }

  return response;
});

export const sendFeedback = createAsyncThunk("sendFeedback", async (data) => {
  console.log("The data for body of request is: ", data);
    const res = await fetch("http://127.0.0.1:8000/contact-form", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
      credentials: "include",
    });

    const response = await res.json();

    console.log(response);

    return response;
})

export const UserSlice = createSlice({
  name: "users",
  initialState: initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(createAction(registerNewUser.pending), (state) => {
        state.loading = true;
      })
      .addCase(createAction(registerNewUser.fulfilled), (state, action) => {
        state.loading = false;
        console.log(
          "The action payload after user registeration successfully is:",
          action.payload
        );
        state.loggedInUser = action.payload.user;
      })
      .addCase(createAction(registerNewUser.rejected), (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(createAction(loginUser.pending), (state) => {
        state.loading = true;
      })
      .addCase(createAction(loginUser.fulfilled), (state, action) => {
        state.loading = false;
        console.log("The payload of action is: ", action.payload);
        state.loggedInUser = action.payload.user;
      })
      .addCase(createAction(loginUser.rejected), (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(createAction(sendFeedback.pending), (state) => {
        state.loading = true;
      })
      .addCase(createAction(sendFeedback.fulfilled), (state) => {
        state.loading = false;
      })
      .addCase(createAction(sendFeedback.rejected), (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(createAction(getUserDetails.pending), (state) => {
        state.loading = true;
      })
      .addCase(createAction(getUserDetails.fulfilled), (state, action) => {
        state.loading = false;
        console.log(
          "The payload of action of get user details is: ",
          action.payload
        );
        // state.loggedInUser = action.payload.user;
      })
      .addCase(createAction(getUserDetails.rejected), (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export default UserSlice.reducer;
