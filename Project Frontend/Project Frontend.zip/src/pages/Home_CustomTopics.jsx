import CustomTopics from "../components/CustomTopics";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

const Home_CustomTopics = () => {
  return (
    <div>
      {/* <Navbar /> */}
      {/* <HeroSection /> */}
      <CustomTopics />
      {/* <Footer /> */}
    </div>
  );
};

export default Home_CustomTopics;
