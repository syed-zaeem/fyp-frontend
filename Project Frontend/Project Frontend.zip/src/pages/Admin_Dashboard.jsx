import React from 'react'

const Admin_Dashboard = () => {
  return (
    <div>
      This is the admin dashboard.
    </div>
  )
}

export default Admin_Dashboard
